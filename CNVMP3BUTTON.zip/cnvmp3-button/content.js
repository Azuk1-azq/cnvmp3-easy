const CNV_URL = "https://cnvmp3.com/"; // 変わった場合は rules.json / manifest.json も修正
let job = null;
let frame = null;
let frameReady = false;

function getVideoUrl() {
  const v = new URLSearchParams(location.search).get("v");
  if (location.pathname === "/watch" && v) return `https://www.youtube.com/watch?v=${v}`;
  const s = location.pathname.match(/^\/shorts\/([\w-]+)/);
  // Shortsは通常の動画URLに変換（cnvmp3が確実に受け付ける形式）
  return s ? `https://www.youtube.com/watch?v=${s[1]}` : null;
}

// ---------- 裏で動くcnvmp3（事前読み込み） ----------
function warm() {
  if (frame) return;
  const wrap = document.createElement("div");
  wrap.id = "cnv-frame-wrap"; // 通常は画面外・透明。「確認」リンクで表示
  frame = document.createElement("iframe");
  frame.src = CNV_URL + "#warm";
  wrap.appendChild(frame);
  document.body.appendChild(wrap);
  frameReady = false;
}

function resetFrame() {
  document.getElementById("cnv-frame-wrap")?.remove();
  frame = null;
  frameReady = false;
  setTimeout(warm, 800); // 次回のために新しく読み込んでおく
}

function sendStart() {
  if (!job || job.sent || !frameReady) return;
  job.sent = true;
  setText("変換を開始…");
  frame.contentWindow.postMessage(
    { source: "cnvmp3-ext-cmd", type: "start", yt: job.url, fmt: job.fmt },
    "*"
  );
}

// ---------- 独自UI ----------
function beep() {
  try {
    const ctx = new AudioContext();
    [880, 1320].forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = f;
      o.connect(g);
      g.connect(ctx.destination);
      const t = ctx.currentTime + i * 0.14;
      g.gain.setValueAtTime(0.15, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
      o.start(t);
      o.stop(t + 0.25);
    });
  } catch (_) {}
}

function render() {
  const toast = document.getElementById("cnv-toast");
  if (!toast || !job) return;
  const sec = Math.floor((Date.now() - job.started) / 1000);
  toast.querySelector(".cnv-status").textContent =
    job.kind === "work" ? `${job.text}（${sec}秒）` : job.text;
}

function setText(text) {
  if (!job) return;
  job.text = text;
  render();
}

function finish(kind, title, text, downloadId) {
  if (!job || job.kind !== "work") return;
  clearInterval(job.timer);
  clearTimeout(job.doneTimer);
  job.kind = kind;
  job.text = text;
  const toast = document.getElementById("cnv-toast");
  toast.dataset.kind = kind;
  toast.querySelector(".cnv-title").textContent = title;
  if (kind === "ok") {
    beep();
    if (downloadId != null) {
      const a = toast.querySelector(".cnv-folder");
      a.hidden = false;
      a.onclick = (e) => {
        e.preventDefault();
        chrome.runtime.sendMessage({ type: "show", id: downloadId });
      };
    }
    setTimeout(() => job?.kind === "ok" && endJob(), 30000);
  }
  render();
  resetFrame();
}

function endJob() {
  if (!job) return;
  clearInterval(job.timer);
  const wasWorking = job.kind === "work" && job.sent;
  document.getElementById("cnv-toast")?.remove();
  job = null;
  if (wasWorking) resetFrame();
}

function buildToast(fmt) {
  const toast = document.createElement("div");
  toast.id = "cnv-toast";
  toast.dataset.kind = "work";
  toast.innerHTML = `
    <div class="cnv-row">
      <b class="cnv-title"></b>
      <button class="cnv-close" title="閉じる"><svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></button>
    </div>
    <div class="cnv-status">準備中…</div>
    <div class="cnv-bar"></div>
    <a class="cnv-folder" href="#" hidden>📂 フォルダで表示</a>
    <a class="cnv-show" href="#">cnvmp3の画面を表示して確認</a>
    <a class="cnv-coffee" href="https://ko-fi.com/cnvmp3" target="_blank" rel="noopener noreferrer">☕ cnvmp3を支援する</a>`;
  toast.querySelector(".cnv-title").textContent = `${fmt.toUpperCase()} に変換`;
  toast.querySelector(".cnv-close").addEventListener("click", endJob);
  toast.querySelector(".cnv-show").addEventListener("click", (e) => {
    e.preventDefault();
    document.getElementById("cnv-frame-wrap")?.classList.toggle("cnv-visible");
  });
  document.body.appendChild(toast);
}

// ---------- ジョブ開始 ----------
function startJob(fmt) {
  const url = getVideoUrl();
  if (!url) return;
  endJob();
  buildToast(fmt);
  warm();
  job = { fmt, url, kind: "work", text: "準備中…", started: Date.now(), sent: false };
  job.timer = setInterval(() => {
    if (Date.now() - job.started > 180000) {
      finish("err", "⚠ 応答なし", "cnvmp3の画面を表示して確認してください");
    } else render();
  }, 1000);
  render();
  sendStart(); // すでに準備できていれば即開始
}

// ---------- iframe / 背景スクリプトからの通知 ----------
window.addEventListener("message", (e) => {
  let host = "";
  try { host = new URL(e.origin).hostname; } catch (_) { return; }
  if (!/(^|\.)cnvmp3\.com$/.test(host)) return;
  const d = e.data;
  if (!d || d.source !== "cnvmp3-ext") return;
  if (d.type === "ready") { frameReady = true; sendStart(); return; }
  if (!job || job.kind !== "work") return;
  switch (d.type) {
    case "submitted": setText("変換中…"); break;
    case "done":
      // 変換成功（AGAIN表示）。保存の検知を少し待ち、来なければ変換完了として表示
      setText("変換完了。保存中…");
      job.doneTimer = setTimeout(
        () => finish("ok", "✓ 変換完了", "保存が始まらない場合は「cnvmp3の画面を表示」で確認してください"),
        4000
      );
      break;
    case "progress":  setText(`変換中… ${d.detail}`); break;
    case "error":     finish("err", "⚠ 失敗", d.detail); break;
    case "notfound":  finish("err", "⚠ 失敗", `${d.detail}（画面を表示して確認できます）`); break;
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (!job || job.kind !== "work" || msg.source !== "cnvmp3-ext-bg") return;
  if (msg.type === "dl-start") {
    clearTimeout(job.doneTimer);
    setText("ダウンロード中…");
  }
  if (msg.type === "dl-done") finish("ok", "✓ 保存完了", msg.filename || "ダウンロードフォルダに保存しました", msg.id);
  if (msg.type === "dl-error") finish("err", "⚠ 失敗", "ダウンロードに失敗しました");
});

// ---------- ボタン（高評価などが並ぶ場所に配置） ----------
const SVG_NS = "http://www.w3.org/2000/svg";
const ICONS = {
  mp3: "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z",
  mp4: "M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z",
};

function makeIcon(fmt, size) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("width", size);
  svg.setAttribute("height", size);
  svg.setAttribute("focusable", "false");
  const path = document.createElementNS(SVG_NS, "path");
  path.setAttribute("d", ICONS[fmt]);
  path.setAttribute("fill", "currentColor");
  svg.appendChild(path);
  return svg;
}

function bind(el, fmt) {
  el.addEventListener("mouseenter", warm); // マウスを乗せた時点で裏で読み込み開始
  el.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    startJob(fmt);
  });
}

function makeGroup(mode) {
  const g = document.createElement("div");
  g.id = "cnv-actions";
  g.className = `cnv-${mode}`;
  g.dataset.mode = mode;
  for (const fmt of ["mp3", "mp4"]) {
    const label = fmt.toUpperCase();
    if (mode === "shorts") {
      // Shortsの縦並びアクション（丸ボタン＋下にラベル）
      const item = document.createElement("div");
      item.className = "cnv-short-item";
      const b = document.createElement("button");
      b.className = "cnv-round";
      b.type = "button";
      b.title = `${label}として保存`;
      b.appendChild(makeIcon(fmt, 24));
      const t = document.createElement("span");
      t.className = "cnv-label";
      t.textContent = label;
      bind(b, fmt);
      bind(t, fmt);
      item.append(b, t);
      g.appendChild(item);
    } else {
      // 動画下の横並び（YouTube標準のトーナルボタン風）
      const b = document.createElement("button");
      b.className = "cnv-pill";
      b.type = "button";
      b.title = `${label}として保存`;
      const t = document.createElement("span");
      t.textContent = label;
      b.append(makeIcon(fmt, 20), t);
      bind(b, fmt);
      g.appendChild(b);
    }
  }
  return g;
}

// Shortsの縦ボタン列（高評価・低評価・コメント・共有…）を探す
function findShortsActionColumn() {
  const reels = [...document.querySelectorAll("ytd-reel-video-renderer")];
  const inView = (r) => {
    const b = r.getBoundingClientRect();
    return b.top < innerHeight * 0.6 && b.bottom > innerHeight * 0.4;
  };
  const scope = reels.find((r) => r.hasAttribute("is-active")) || reels.find(inView) || document;

  // 高評価ボタン本体を探す（タグ名 → aria-label の順）
  const like =
    scope.querySelector("like-button-view-model, ytd-like-button-renderer, #like-button") ||
    scope.querySelector("[aria-label*='like' i], [aria-label*='高評価']");
  if (!like) return null;

  // 高評価から上に辿り、子要素が3つ以上ある最初の親 = ボタン列
  let el = like;
  while (el.parentElement && el.parentElement !== scope && el.parentElement !== document.body) {
    if (el.parentElement.children.length >= 3) return el.parentElement;
    el = el.parentElement;
  }
  return null;
}

function ensureButtons() {
  const groups = [...document.querySelectorAll("#cnv-actions")];
  const onWatch = location.pathname === "/watch";
  const onShorts = location.pathname.startsWith("/shorts/");
  if (!onWatch && !onShorts) { groups.forEach((g) => g.remove()); return; }

  let host, mode;
  if (onWatch) {
    // 高評価・共有ボタンが並ぶ行
    host = document.querySelector("ytd-watch-metadata #top-level-buttons-computed");
    mode = "inline";
    if (!host) return; // まだ描画されていない
  } else {
    // Shortsの縦ボタン列（高評価・コメント・共有…）。見つからなければ動画の左上に浮かせる
    host = findShortsActionColumn();
    mode = host ? "shorts" : "float";
    if (!host) host = document.body;
  }

  if (groups.length === 1 && groups[0].dataset.mode === mode && host.contains(groups[0])) return;
  groups.forEach((g) => g.remove());
  const g = makeGroup(mode);

  if (mode === "inline") {
    const like = host.querySelector(
      "segmented-like-dislike-button-view-model, ytd-segmented-like-dislike-button-renderer"
    );
    like ? like.after(g) : host.prepend(g); // 高評価ボタンのすぐ右
  } else {
    host.appendChild(g);
  }
}

// フォールバック用: 表示中のショート動画の左上にボタンを追従させる
function positionFloat() {
  const g = document.getElementById("cnv-actions");
  if (!g || g.dataset.mode !== "float") return;
  const el =
    document.querySelector("ytd-reel-video-renderer[is-active] video") ||
    document.querySelector("ytd-reel-video-renderer[is-active] #player-container") ||
    document.querySelector("ytd-reel-video-renderer[is-active]");
  const r = el && el.getBoundingClientRect();
  if (r && r.width > 0 && r.height > 0) {
    g.style.left = `${Math.max(8, r.left + 12)}px`;
    g.style.top = `${Math.max(8, r.top + 12)}px`;
    g.style.bottom = "auto";
  }
}
setInterval(positionFloat, 400);

document.addEventListener("yt-navigate-finish", () => {
  endJob();
  ensureButtons();
  positionFloat();
});
new MutationObserver(ensureButtons).observe(document.body, { childList: true, subtree: true });
ensureButtons();
