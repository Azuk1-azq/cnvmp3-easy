// 日本語 / English の文言（content.js・設定ページ・ウェルカムページで共有）
const I18N = {
 "saveAs": [
  "{0}として保存",
  "Save as {0}"
 ],
 "audioQ": [
  "音質",
  "Audio quality"
 ],
 "videoQ": [
  "画質",
  "Video quality"
 ],
 "convertTo": [
  "{0}（{1}）に変換",
  "Convert to {0} ({1})"
 ],
 "preparing": [
  "準備中…",
  "Preparing…"
 ],
 "starting": [
  "変換を開始…",
  "Starting…"
 ],
 "converting": [
  "変換中…",
  "Converting…"
 ],
 "convertingPct": [
  "変換中… {0}%",
  "Converting… {0}%"
 ],
 "finishing": [
  "仕上げ中…",
  "Finishing up…"
 ],
 "convertedSaving": [
  "変換完了。保存中…",
  "Converted. Saving…"
 ],
 "downloading": [
  "ダウンロード中…",
  "Downloading…"
 ],
 "savedTitle": [
  "✓ 保存完了",
  "✓ Saved"
 ],
 "savedToFolder": [
  "ダウンロードフォルダに保存しました",
  "Saved to your downloads folder"
 ],
 "failedTitle": [
  "⚠ 失敗",
  "⚠ Failed"
 ],
 "noResponse": [
  "⚠ 応答なし",
  "⚠ No response"
 ],
 "timeoutMsg": [
  "拡張機能の設定で「cnvmp3の画面を表示」をオンにして確認してください",
  "Turn on “Show the cnvmp3 screen” in the extension settings to check."
 ],
 "dlFailed": [
  "ダウンロードに失敗しました",
  "The download failed."
 ],
 "convertedTitle": [
  "✓ 変換完了",
  "✓ Converted"
 ],
 "nf_noinput": [
  "入力欄が見つかりません",
  "Couldn’t find the input field."
 ],
 "nf_nobutton": [
  "変換ボタンが見つかりません",
  "Couldn’t find the convert button."
 ],
 "nf_loadfail": [
  "cnvmp3の読み込みに失敗しました",
  "Couldn’t load cnvmp3."
 ],
 "checkHint": [
  "（設定で「cnvmp3の画面を表示」をオンにすると確認できます）",
  " (Turn on “Show the cnvmp3 screen” in settings to check.)"
 ],
 "showFolder": [
  "📂 フォルダで表示",
  "📂 Show in folder"
 ],
 "toggleScreen": [
  "cnvmp3の画面を表示／隠す",
  "Show / hide cnvmp3"
 ],
 "support": [
  "☕ cnvmp3を支援する",
  "☕ Support cnvmp3"
 ],
 "settingsTip": [
  "設定",
  "Settings"
 ],
 "closeTip": [
  "閉じる",
  "Close"
 ],
 "version": [
  "バージョン {0}",
  "Version {0}"
 ],
 "secLang": [
  "言語",
  "LANGUAGE"
 ],
 "secDefaults": [
  "変換の既定",
  "DEFAULTS"
 ],
 "secDisplay": [
  "表示",
  "DISPLAY"
 ],
 "secNotify": [
  "通知",
  "NOTIFICATIONS"
 ],
 "langLabel": [
  "言語 / Language",
  "Language / 言語"
 ],
 "mp3q": [
  "MP3の音質",
  "MP3 audio quality"
 ],
 "mp4q": [
  "MP4の画質",
  "MP4 video quality"
 ],
 "showScreen": [
  "cnvmp3の画面を表示する",
  "Show the cnvmp3 screen"
 ],
 "showScreenDesc": [
  "通常は非表示です。変換がうまくいかないときの確認用。",
  "Hidden by default. Use it to check when a conversion doesn’t work."
 ],
 "sound": [
  "完了時に通知音を鳴らす",
  "Play a chime when finished"
 ],
 "autoClose": [
  "完了カードを閉じるまで",
  "Close the finished card after"
 ],
 "s10": [
  "10秒",
  "10 sec"
 ],
 "s30": [
  "30秒",
  "30 sec"
 ],
 "s60": [
  "60秒",
  "60 sec"
 ],
 "never": [
  "自動で閉じない",
  "Never"
 ],
 "saved": [
  "保存しました",
  "Saved"
 ],
 "wLangTitle": [
  "言語を選んでください / Choose your language",
  "Choose your language / 言語を選んでください"
 ],
 "wTitle2": [
  "最初の設定",
  "First-time setup"
 ],
 "wDefaultsDesc": [
  "あとから、拡張機能アイコンの設定でいつでも変えられます。",
  "You can change these anytime from the extension icon."
 ],
 "wGo": [
  "始める",
  "Get started"
 ],
 "wDoneTitle": [
  "準備ができました",
  "You’re all set"
 ],
 "wDoneDesc": [
  "YouTubeの動画を開くと、高評価ボタンの隣に MP3 / MP4 ボタンが表示されます。すでに開いているYouTubeは再読み込みしてください。",
  "Open a YouTube video and you’ll see MP3 / MP4 buttons next to the Like button. Reload any YouTube tabs that are already open."
 ],
 "wOpenYt": [
  "YouTubeを開く",
  "Open YouTube"
 ],
 "qTip": [
  "{0}（この1回だけ変更。いつもの設定は拡張機能アイコンから変えられます）",
  "{0} (this time only — change your usual setting from the extension icon)"
 ],
 "defaultNote": [
  "いつも使う設定です。YouTube上のメニューで変えた分は、その1回だけ有効です。",
  "Your usual settings. Changes made on YouTube apply to that one conversion only."
 ],
 "wQTitle": [
  "音質と画質を決めましょう",
  "Choose your audio and video quality"
 ],
 "wQDesc": [
  "いつも使う設定です。YouTubeの画面から、その1回だけ変えることもできます。",
  "This is your usual setting. On YouTube you can also change it for just one conversion."
 ],
 "wAudio": [
  "音質（MP3）",
  "AUDIO QUALITY (MP3)"
 ],
 "wVideo": [
  "画質（MP4）",
  "VIDEO QUALITY (MP4)"
 ],
 "recommended": [
  "おすすめ",
  "Recommended"
 ],
 "tempMenu": [
  "YouTubeで「今回だけ音質・画質を変える」を使う",
  "Allow “change quality just this once” on YouTube"
 ],
 "tempMenuDesc": [
  "オフにすると、MP3 / MP4 ボタンの横のプルダウンを隠し、いつもの設定で変換します。",
  "When off, the dropdown next to the MP3 / MP4 buttons is hidden and your usual setting is always used."
 ],
 "wStep1": [
  "言語",
  "Language"
 ],
 "wStep2": [
  "音質・画質",
  "Quality"
 ],
 "wStep3": [
  "完了",
  "Done"
 ],
 "wBack": [
  "戻る",
  "Back"
 ]
};
function defaultLang() {
  try { return chrome.i18n.getUILanguage().toLowerCase().startsWith("ja") ? "ja" : "en"; } catch (_) { return "ja"; }
}
let LANG = defaultLang();
function tr(key, ...args) {
  const e = I18N[key];
  let s = e ? (LANG === "en" ? e[1] : e[0]) : key;
  args.forEach((a, i) => { s = s.replace(`{${i}}`, a); });
  return s;
}
