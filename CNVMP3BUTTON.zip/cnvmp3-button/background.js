// ダウンロードの開始・完了を検知して、YouTubeタブの独自UIに通知する
const ids = new Set();

function broadcast(msg) {
  chrome.tabs.query({ url: "https://www.youtube.com/*" }, (tabs) => {
    tabs.forEach((t) =>
      chrome.tabs.sendMessage(t.id, { source: "cnvmp3-ext-bg", ...msg }).catch(() => {})
    );
  });
}

chrome.downloads.onCreated.addListener((item) => {
  ids.add(item.id);
  broadcast({ type: "dl-start", id: item.id });
});

chrome.downloads.onChanged.addListener((delta) => {
  if (!ids.has(delta.id) || !delta.state) return;
  const state = delta.state.current;
  if (state === "complete") {
    chrome.downloads.search({ id: delta.id }, ([item]) => {
      broadcast({
        type: "dl-done",
        id: delta.id,
        filename: item?.filename?.split(/[\\/]/).pop() || "",
      });
    });
    ids.delete(delta.id);
  } else if (state === "interrupted") {
    broadcast({ type: "dl-error", id: delta.id });
    ids.delete(delta.id);
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "show") chrome.downloads.show(msg.id);
});
