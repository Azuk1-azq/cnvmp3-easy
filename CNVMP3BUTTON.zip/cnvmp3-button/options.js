const QUALITY = {
  mp3: [["64","64kbps"],["96","96kbps"],["128","128kbps"],["192","192kbps"],["256","256kbps"],["320","320kbps"]],
  mp4: [["360","360p"],["480","480p"],["720","720p"],["1080","1080p"]],
};
const settings = { showCnvScreen: false, sound: true, autoCloseSec: 30, showQualityMenu: true };
const quality = { mp3: "192", mp4: "1080" };
const $ = (id) => document.getElementById(id);

for (const fmt of ["mp3", "mp4"]) {
  for (const [v, l] of QUALITY[fmt]) $("q-" + fmt).add(new Option(l, v));
}
function applyI18n() {
  document.documentElement.lang = LANG;
  document.querySelectorAll("[data-i18n]").forEach((el) => (el.textContent = tr(el.dataset.i18n)));
  $("v").textContent = tr("version", chrome.runtime.getManifest().version);
}
let timer;
function flash() {
  $("saved").textContent = tr("saved");
  clearTimeout(timer);
  timer = setTimeout(() => ($("saved").textContent = ""), 1200);
}
function save() {
  chrome.storage.local.set({ cnvSettings: settings, cnvQ: quality }, flash);
}
chrome.storage.local.get(["cnvSettings", "cnvQ"], (r) => {
  Object.assign(settings, r.cnvSettings || {});
  Object.assign(quality, r.cnvQ || {});
  LANG = settings.lang || defaultLang();
  $("lang").value = LANG;
  $("showCnvScreen").checked = !!settings.showCnvScreen;
  $("sound").checked = !!settings.sound;
  $("tempMenu").checked = settings.showQualityMenu !== false;
  $("autoCloseSec").value = String(settings.autoCloseSec);
  $("q-mp3").value = quality.mp3;
  $("q-mp4").value = quality.mp4;
  applyI18n();
});
$("lang").onchange = (e) => { settings.lang = LANG = e.target.value; applyI18n(); save(); };
$("showCnvScreen").onchange = (e) => { settings.showCnvScreen = e.target.checked; save(); };
$("tempMenu").onchange = (e) => { settings.showQualityMenu = e.target.checked; save(); };
$("sound").onchange = (e) => { settings.sound = e.target.checked; save(); };
$("autoCloseSec").onchange = (e) => { settings.autoCloseSec = Number(e.target.value); save(); };
$("q-mp3").onchange = (e) => { quality.mp3 = e.target.value; save(); };
$("q-mp4").onchange = (e) => { quality.mp4 = e.target.value; save(); };
applyI18n();
